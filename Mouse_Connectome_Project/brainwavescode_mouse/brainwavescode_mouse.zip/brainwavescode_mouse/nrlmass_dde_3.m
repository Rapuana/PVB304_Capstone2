function out = nrlmass_dde(t,y,ylag)

global V1 V2 V3 V4 V5 V6 V7 gCa gK gL VK VL VCa I b ani aei aie aee phi V8 V9 gNa VNa ane nse rnmda N CM vs c k_in

% note: 'nse' and 'vs' are not used in this version of the model, but
% passed along as globals nonetheless...

if isempty(ylag)  %if there are no delays
    % init 'out' and vectors for the variable types
    out = zeros(3*N,1);
    v = y(1:3:end);
    w = y(2:3:end);
    z = y(3:3:end);

    % calculate the inter-node inputs using transfer function
    gainv = gain(v,V5,V6,0.5);
    vgainmean = ((gainv'*CM)')./k_in;
    vgainmean(isnan(vgainmean)) = 0;

    % these lines are for a version of the code that incorporates noise (nse)
    %out(1:3:end) = -(gCa+rnmda.*(1-c).*aee.*gainv+rnmda.*c.*aee.*vgainmean).*gain(v,V1,V2,0.5).*(v-VCa) ...
    %               -gK.*w.*(v-VK) ...
    %               -gL.*(v-VL) ... 
    %               -(gNa.*gain(v,V9,V8,0.5)+(1-c).*aee.*gainv+c.*aee.*vgainmean).*(v-VNa) ...
    %               +ane.*(I+nse.*(rand(N,1)-0.5)) ...
    %               -gain(z,V7,V6,aie.*0.5).*z;

    % no noise (i.e. 'nse' = 0 in main script)
    out(1:3:end) = -(gCa+rnmda.*(1-c).*aee.*gainv+rnmda.*c.*aee.*vgainmean).*gain(v,V1,V2,0.5).*(v-VCa) ...
                   -gK.*w.*(v-VK) ...
                   -gL.*(v-VL) ... 
                   -(gNa.*gain(v,V9,V8,0.5)+(1-c).*aee.*gainv+c.*aee.*vgainmean).*(v-VNa) ...
                   +ane.*I ...
                   -gain(z,V7,V6,aie.*0.5).*z;

    out(2:3:end) = phi.*(gain(v,V3,V4,0.5)-w);

    out(3:3:end) = b.*(ani.*I+gain(v,V5,V6,aei.*0.5).*v);

else
        % init 'out' and vectors for the variable types
    out = zeros(3*N,1);
    v = y(1:3:end);
    w = y(2:3:end);
    z = y(3:3:end);

    vlag = ylag(1:3:end);
    
    % kryptic but speed-optimized...
    gainv = gain(v,V5,V6,0.5);
%     vgainmean = ((gainv'*CM)')./k_in;
%     vgainmean(isnan(vgainmean)) = 0;


    gainvlag = gain(vlag,V5,V6,0.5);
    vlaggainmean = ((gainvlag'*CM)')./k_in;
    vlaggainmean(isnan(vlaggainmean)) = 0;

    
    % these lines are for a version of the code that incorporates noise (nse)
    %out(1:3:end) = -(gCa+rnmda.*(1-c).*aee.*gainv+rnmda.*c.*aee.*vgainmean).*gain(v,V1,V2,0.5).*(v-VCa) ...
    %               -gK.*w.*(v-VK) ...
    %               -gL.*(v-VL) ... 
    %               -(gNa.*gain(v,V9,V8,0.5)+(1-c).*aee.*gainv+c.*aee.*vgainmean).*(v-VNa) ...
    %               +ane.*(I+nse.*(rand(N,1)-0.5)) ...
    %               -gain(z,V7,V6,aie.*0.5).*z;

    % no noise (i.e. 'nse' = 0 in main script)
    
    %the problem with the previous version of the code is that the
    %intrinsic circuitry was also being lagged -- not only the
    %inter-node circuitry....
    
    out(1:3:end) = -(gCa+rnmda.*(1-c).*aee.*gainv+rnmda.*c.*aee.*vlaggainmean).*gain(v,V1,V2,0.5).*(v-VCa) ...
                   -gK.*w.*(v-VK) ...
                   -gL.*(v-VL) ... 
                   -(gNa.*gain(v,V9,V8,0.5)+(1-c).*aee.*gainv+c.*aee.*vlaggainmean).*(v-VNa) ...
                   +ane.*I ...
                   -gain(z,V7,V6,aie.*0.5).*z;

    out(2:3:end) = phi.*(gain(v,V3,V4,0.5)-w);

    out(3:3:end) = b.*(ani.*I+gain(v,V5,V6,aei.*0.5).*v);
    
end
